<!DOCTYPE html>
<html>
<title>W3.CSS Template</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-black.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="OverCrowdStyle.php">
<body id="myPage">


<!-- Navbar -->
<div class="w3-top">
 <div class="w3-bar w3-theme-d2 w3-left-align">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-hover-white w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a><a href="#" class="w3-bar-item w3-button w3-teal"><i class="fa fa-home w3-margin-right"></i>OverCrowd</a>
  <a href="#team" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Team</a>
  <a href="#crowded" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Crowds</a>
  <a href="#pricing" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Price</a>
  <a href="#contact" class="w3-bar-item w3-button w3-hide-small w3-hover-white">Contact</a>

 </div>
</div>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-right w3-hover-teal" title="Search"><i class="fa fa-search"></i></a>

  <!-- Navbar on small screens -->
  <div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium">
    <a href="#team" class="w3-bar-item w3-button">Team</a>
    <a href="#crowded" class="w3-bar-item w3-button">Crowds</a>
    <a href="#pricing" class="w3-bar-item w3-button">Price</a>
    <a href="#contact" class="w3-bar-item w3-button">Contact</a>
    <a href="#" class="w3-bar-item w3-button">Search</a>
  </div>

<!-- Image Header -->
<div class="w3-display-container w3-animate-opacity">
<!-- Google Maps -->
    <div id="googleMap" style= "width: 100%; height: 600px;  padding-top: 30px;" >
        <?php
            include 'sqlConn.php';
        ?>
    </div>
</div>

<!-- Work Row -->
<div class="w3-row-padding w3-padding-64 w3-theme-l1" id="crowded">

<div class="w3-row-padding w3-center w3-padding-64" id="crowded">
<h2>How Crowded?</h2>
    <p>See how crowded each bar is before you leave.</p><br>
</div>

<div class="w3-quarter">
<div class="w3-card w3-white">
  <div class="w3-container">
  <h2 style="color: #B95039">Landmark Americana-Glassboro</h2>
  <p>Hours: Mon/Sun: 11am - 2am</p>
  <p>Phone: 856-863-6600</p>
  <p>Address: 1 MULLICA HILL ROAD, GLASSBORO, NJ 08028</p>
  <p>Every Saturday All-You-Can-Eat Wings $12.99</p>
  <p>Kids Eat Free Wednesday and Sunday</p>
  <p>Open Club Every Thursday and Saturday</p>
      <a href = "http://www.landmarkamericana.com/g-home/" class = "btn btn-default"> Go To Website </a>

  </div>
  </div>
</div>

<div class="w3-quarter">
<div class="w3-card w3-white">
  <div class="w3-container">
  <h2 style="color: #B95039">Chickie's and Pete's</h2>
  <p>Bar Hours: 11am - 2am</p>
  <p>Kitchen Hours: Mon/Thurs: 11am - 12am</p>
  <p>Kitchen Hours: Fri/Sat: 11am - 1am</p>
  <p>Address: 234 Rowan Boulevard, Glassboro, NJ 08028</p>
  <p>Phone: (856) 307-2490</p>

      <a href = "https://chickiesandpetes.com/location/glassboro-2/" class = "btn btn-default"> Go To Website </a>

  </div>
  </div>
</div>

<div class="w3-quarter">
<div class="w3-card w3-white">
  <div class="w3-container">
  <h2 style="color: #B95039">Kegler's Bar</h2>
  <p>Bar Hours: Mon/Thurs: - 6pm - 12am</p>
  <p>Bar Hours: Fri/Sat: 6pm - 2am</p>
  <p>Address: 503 N. Delsea, Glassboro, NJ 08028</p>
  <p>Phone: (856) 881-1011</p>
      <a href = "http://glassborobowlnj.com/Keglers" class = "btn btn-default"> Go To Website </a>

  </div>
  </div>
</div>
    
<div class="w3-quarter">
<div class="w3-card w3-white">
  <div class="w3-container">
  <h2 style="color: #B95039">Terra Nova</h2>
  <p>Hours: Mon/Thurs: 11:30am - 10pm</p>
  <p>Hours: Fri/Sat: 11:30am - 11pm</p>
  <p>Hours: Sun: 12pm - 9pm</p>
  <p>Address: 590 Delsea Drive, Sewell NJ 08080</p>
  <p>Phone: (856) 589-8883</p>

      <a href = "http://www.landmarkamericana.com/g-home/" class = "btn btn-default"> Go To Website </a>

  </div>
  </div>
</div>

</div>

<!-- Container -->
<div class="w3-container" style="position:relative">
  <a onclick="w3_open()" class="w3-button w3-xlarge w3-circle w3-teal"
  style="position:absolute;top:-28px;right:24px">+</a>
</div>

<!-- Pricing Row -->
<div class="w3-row-padding w3-center w3-padding-64" id="pricing">
    <h2>DEALS</h2>
    <p>Look at the closest bars deals near you.</p><br>
    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-hover-shadow">
        <li class="w3-theme">
            <p>
            <?php
            
                $servername = "localhost";
                $username = "root";
                $password = "mysql";
                $dbname = "OvercrowdDB";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                } 

                $sql = "SELECT name FROM GoogleMapsInfo WHERE name='Terra Nova'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo $row["name"]. "<br>";
                    }
                } else {
                    echo "0 results";
                }
                $conn->close();

            
            ?>
            </p>
          
        </li>
          <li class="w3-padding-16"><b>Monday: </b>   
              <?php
            
                $servername = "localhost";
                $username = "root";
                $password = "mysql";
                $dbname = "OvercrowdDB";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                } 

                $sql = "SELECT name FROM Deals";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo $row["Monday"]. "<br>";
                    }
                } else {
                    echo "Waiting for vendor";
                }
                $conn->close();

            
            ?>
          </li>
          <li class="w3-padding-16"><b>Tuesday: </b> DEALS</li>
          <li class="w3-padding-16"><b>Wednesday: </b> DEALS</li>
          <li class="w3-padding-16"><b>Thursday: </b> DEALS</li>
        <li class="w3-padding-16"><b>Friday: </b> DEALS </li>
        <li class="w3-padding-16"><b>Saturday: </b> DEALS </li>
        <li class="w3-padding-16"><b>Sunday: </b> DEALS</li>  

      </ul>
    </div>

    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-hover-shadow">
        <li class="w3-theme-l2">
          <p>
                     
            <?php
            
                $servername = "localhost";
                $username = "root";
                $password = "mysql";
                $dbname = "OvercrowdDB";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                } 

                $sql = "SELECT name FROM GoogleMapsInfo WHERE name='Bogeys Cafe & Club'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo $row["name"]. "<br>";
                    }
                } else {
                    echo "0 results";
                }
                $conn->close();

            
            ?>
            </p>
         
        </li>
        <li class="w3-padding-16"><b>Monday: </b> DEALS</li>
          <li class="w3-padding-16"><b>Tuesday: </b> DEALS</li>
          <li class="w3-padding-16"><b>Wednesday: </b> DEALS</li>
          <li class="w3-padding-16"><b>Thursday: </b> DEALS</li>
        <li class="w3-padding-16"><b>Friday: </b> DEALS </li>
        <li class="w3-padding-16"><b>Saturday: </b> DEALS </li>
        <li class="w3-padding-16"><b>Sunday: </b> DEALS</li>  
      </ul>
    </div>

    <div class="w3-third w3-margin-bottom">
      <ul class="w3-ul w3-border w3-hover-shadow">
        <li class="w3-theme">
          <p>
            
            <?php
            
                $servername = "localhost";
                $username = "root";
                $password = "mysql";
                $dbname = "OvercrowdDB";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);
                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                } 

                $sql = "SELECT name FROM GoogleMapsInfo WHERE name='Peking Buffet'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo $row["name"]. "<br>";
                    }
                } else {
                    echo "0 results";
                }
                $conn->close();

            
            ?>
            </p>
            
        </li>
          <li class="w3-padding-16"><b>Monday: </b> DEALS</li>
          <li class="w3-padding-16"><b>Tuesday: </b> DEALS</li>
          <li class="w3-padding-16"><b>Wednesday: </b> DEALS</li>
          <li class="w3-padding-16"><b>Thursday: </b> DEALS</li>
        <li class="w3-padding-16"><b>Friday: </b> DEALS </li>
        <li class="w3-padding-16"><b>Saturday: </b> DEALS </li>
        <li class="w3-padding-16"><b>Sunday: </b> DEALS</li>  

      </ul>
    </div>
</div>

<!--
To use this code on your website, get a free API key from Google.
Read more at: https://www.w3schools.com/graphics/google_maps_basic.asp
-->
<!-- Team Container -->
<div class="w3-container w3-padding-64 w3-center" id="team">
<h2>OUR TEAM</h2>
<p>Meet the team - our office rats:</p>

<div class="w3-row"><br>

<div class="w3-quarter">
  <img src="images/boss-baby-point.png" alt="Boss" style="width:45%; margin-bottom: 11%;" class=" w3-hover-opacity">
  <h3>John Kapoian</h3>
  <p>Web Designer</p>
</div>

<div class="w3-quarter">
  <img src="images/Kristian.png" alt="Boss" style="width:45%; margin-bottom: 6%;" class=" w3-hover-opacity">
    <h3>Kristian Hill</h3>
  <p>Support</p>
</div>

<div class="w3-quarter">
  <img src="images/Boss-Image-400.png" alt="Boss" style="width:45%" class="w3-hover-opacity">
  <h3>Alex Rebmann</h3>
  <p>Pinkies Out</p>
</div>

<div class="w3-quarter">
  <img src="images/MikeLu.png" alt="Boss" style="width:45%; margin-bottom: 18%;" class=" w3-hover-opacity">
  <h3>Mike Lu</h3>
  <p>Fixer</p>
</div>

</div>
</div>
    
<!-- Footer -->
<?php
    include 'footer.html';
?>

<script>
// Script for side navigation
function w3_open() {
    var x = document.getElementById("mySidebar");
    x.style.width = "300px";
    x.style.paddingTop = "10%";
    x.style.display = "block";
}

// Close side navigation
function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
    var x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>
</body>
</html>
