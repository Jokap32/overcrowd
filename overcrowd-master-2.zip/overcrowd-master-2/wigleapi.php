<html<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Wigle Test</title>
</head>
<body>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<br>";



function checkName(&$name) {

    $name = str_replace(" ", "", trim($name));
    $name = stripslashes($name);
    $name = htmlspecialchars($name);

    if (empty($_POST['wifiname'])) {
        return false;
    }
    return true;
}

function checkJSON($data) {
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        echo "incorrect data";
        return false;
    }
    return true;
}

function grabJSON($JSONArray, $data) {
    if(!empty($JSONArray["results"][0][$data])) {
        if ($JSONArray["results"][0][$data] === null && json_last_error() !== JSON_ERROR_NONE) {
            echo "incorrect data";
            return false;
        } else {
            return false;
        }
    }else {
        return true;
    }

}

$validName = false;

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $wifiname = $_POST['wifiname'];

    $validName = checkName($wifiname);
}

if($validName) {
    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $databaseName = "OvercrowdDB";


    $connection = new mysqli($servername, $username, $password, $databaseName);

    if($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    $checkSQL = 'SELECT * FROM Wifi WHERE SSID = "' . $wifiname . '"';
    $result = $connection->query($checkSQL);

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "SSID: " . $row["SSID"]. "<br>NetID: " . $row["netid"]. "<br>Road: " . $row["road"]. "<br>City: " . $row["city"] . "<br>Region: " . $row["region"];
        }
    } else {
        echo "0 results";
        $url = 'https://api.wigle.net/api/v2/network/search?onlymine=false&freenet=false&paynet=false&ssidlike=' . $wifiname . '&resultsPerPage=5';
        $curl = curl_init($url);

        $headers = array(
            'Accept:application/json',
            'Authorization: Basic QUlEN2NhNThkMmI5OWFmYjk3OTlhN2U2ZmRiZjY5OGJjYTI6ZWM4YzZjMTVjMTZjNmUxOGE4NGY1ZDc4NjJjNDRiNDQ='
        );

        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $result = curl_exec($curl);

        $netidcheck = $ssidcheck = $roadcheck = $citycheck = $regioncheck = $inputcheck = false;

        curl_close($curl);
        $resultdecoded = json_decode($result, true);


        $netidcheck = grabJSON($resultdecoded, "netid");
        $ssidcheck = grabJSON($resultdecoded, "ssid");
        $roadcheck = grabJSON($resultdecoded, "road");
        $citycheck = grabJSON($resultdecoded, "city");
        $regioncheck = grabJSON($resultdecoded, "region");

        $inputcheck = $netidcheck && $ssidcheck && $roadcheck && $citycheck && $regioncheck;

        if($inputcheck) {

            $netid = $resultdecoded["results"][0]["ssid"];
            $ssid = $resultdecoded["results"][0]["ssid"];
            $road = $resultdecoded["results"][0]["road"];
            $city = $resultdecoded["results"][0]["city"];
            $region = $resultdecoded["results"][0]["region"];

            $insertSQL = "INSERT INTO Wifi (SSID, netid, road, city, region) VALUES('$ssid', '$netid', '$road', '$city', '$region')";

            if ($connection->query($insertSQL) === TRUE) {
                echo "Success: We will submit the following information<br>";
                echo "SSID: " . $ssid . "<br>";
                echo "NetID: " . $netid . "<br>";
                echo "Road: " . $road . "<br>";
                echo "City: " . $city . "<br>";
                echo "Region: " . $region . "<br>";
            }	else {
                echo "Error: " . $insertSQL . "<br>" . $connection->error;
            }
        } else {
            echo "";
        }


    }


    $connection->close();

} else {
    ?>
    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" >
        Wifi Name: <input type="text" name="wifiname"> <span style="color:red">*Name is required</span><br><br>
        <input type="submit" name="submit" value="submit">
    </form>
    <?php
}?>
</body>
</html>