
<?php

include 'newMapSearch.php'

$servername = "localhost";
$username = "root";
$password = "mysql";
$dbname = "OvercrowdDB";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "CREATE TABLE table1 (

        name INT(30) NOT NULL)";
        
if ($conn->query($sql) === TRUE) {
    echo "Table MyGuests created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$insertsql = "INSERT INTO table1 VALUES ('result_name')";






/*
<?php

    include 'newMapSearch.php';
    
    $servername = "localhost";
    $username = "root";
    $password = "mysql";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password);
    // Check connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    //Create_database
    $sql = "CREATE DATABASE myDB";
    if (mysqli_query($conn, $sql)) {
        echo "Database created successfully";
    } else {
        echo "Error creating database: " . mysqli_error($conn);
    }
    
    $sql1 = "CREATE TABLE try1DB";
    if(mysqli_query($conn, $sql1)){ 
        echo "Table created successfully";
        $insertSQL = "INSERT INTO try1DB VALUES('result_name')";
    } else {
        echo "Error creating database: " . mysqli_error($conn);
    }

    mysqli_close($conn);
?>

CREATE TABLE try1DB (

    `result_name` VARCHAR(9) CHARACTER SET utf8,

);

INSERT INTO try1DB VALUES('result_name');

INSERT INTO GoogleMapsInfo VALUES ('Glassboro','Glassboro','locality',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO GoogleMapsInfo VALUES ('United States','US','political','<span class="locality">Glassboro</span>, <span class="region">NJ</span>, <span class="country-name">USA</span>','Glassboro, NJ, USA',39.7028923,-75.1118422,39.73739,-75.054785,39.678584,-75.168261,'https://maps.gstatic.com/mapfiles/place_api/icons/geocode-71.png','7b22796788250d00d097bd178d16f7e4f5236e73','Glassboro',720,'<a href="https://maps.google.com/maps/contrib/115483902225064151271/photos">MJAD Productions</a>','CmRaAAAAIdTuWGxMhKr1P5UQmabEE607f4VHAr69Emfa58-CiM-t0V1HjdEW65Xx9ym1X-4A4XTtTMFmfPFbWjCYWsRTcCzszN3d19nQjiGhUtDkc5Kulp7m1XRv7P4BZtdT05QpEhC0bqykzODuQ0YIlP-xxbuGGhSlkED51Baq3AfFXqTCULoUWhUC6Q',960,'ChIJxV2EravXxokRAgD39USJdls','CmRbAAAAr9Vyjf4Vq1TIzf3RsN_J1_efjRFaYHEcxjLcolYCrM_7n6tGS6DYq7UbQz3InribVRdmu2kKP92G7mOEyi6oRVZrT4ttL61tvpDwpSQ1v6tVlxB1AVBuaSBtJAXIqQ03EhCMmV3Drh7nWStpZJ_a2VECGhQOnZX-e_58k6fzHrNTB5JJn4oKCg','GOOGLE','locality',NULL,NULL,NULL,NULL);
INSERT INTO try1DB VALUES ('United States','US','political','<span class="locality">Glassboro</span>, <span class="region">NJ</span>, <span class="country-name">USA</span>','Glassboro, NJ, USA',39.7028923,-75.1118422,39.73739,-75.054785,39.678584,-75.168261,'https://maps.gstatic.com/mapfiles/place_api/icons/geocode-71.png','7b22796788250d00d097bd178d16f7e4f5236e73','Glassboro',720,'<a href="https://maps.google.com/maps/contrib/115483902225064151271/photos">MJAD Productions</a>','CmRaAAAAIdTuWGxMhKr1P5UQmabEE607f4VHAr69Emfa58-CiM-t0V1HjdEW65Xx9ym1X-4A4XTtTMFmfPFbWjCYWsRTcCzszN3d19nQjiGhUtDkc5Kulp7m1XRv7P4BZtdT05QpEhC0bqykzODuQ0YIlP-xxbuGGhSlkED51Baq3AfFXqTCULoUWhUC6Q',960,'ChIJxV2EravXxokRAgD39USJdls','CmRbAAAAr9Vyjf4Vq1TIzf3RsN_J1_efjRFaYHEcxjLcolYCrM_7n6tGS6DYq7UbQz3InribVRdmu2kKP92G7mOEyi6oRVZrT4ttL61tvpDwpSQ1v6tVlxB1AVBuaSBtJAXIqQ03EhCMmV3Drh7nWStpZJ_a2VECGhQOnZX-e_58k6fzHrNTB5JJn4oKCg','GOOGLE','political','https://maps.google.com/?q=Glassboro,+NJ,+USA&ftid=0x89c6d7abad845dc5:0x5b768944f5f70002',-240,'Glassboro','OK');*/
