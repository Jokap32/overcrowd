
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
        <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAcGUrwE1G51IBtZo5GhS5GDcg1uDPmVR4&libraries=places">
        </script>
        <script>
        var map;
        var infowindow;
        var request;
        var service;
        var markers = [];

        function initialize(){
            var center = new google.maps.LatLng(39.7138731, -75.1270613);
            map = new google.maps.Map(document.getElementById('map'), {
                center: center,
                zoom: 13
                });

            request = {
                location: center,
                radius: 8047,
                types: ['restaurant']
            };

            infowindow = new google.maps.InfoWindow();

            service = new google.maps.places.PlacesService(map);

            service.nearbySearch(request, callback);

            google.maps.event.addListener(map, 'rightclick', function(event){
                map.setCenter(event.latLng)
                clearResults(markers)

                var request = {
                    location: event.latLng,
                    radius: 8047,
                    types: ['bar', 'restaurant', 'liquor_store']
                };
                service.nearbySearch(request, callback);
            })
        }

        function callback(results, status){
            if(status === google.maps.places.PlacesServiceStatus.OK){
                for(var i = 0; i < results.length; i++){
                    markers.push(createMarker(results[i]));
                }
                
                for(var j = 0; j<results.length; j++){
                    
                    console.log(JSON.parse(JSON.stringify(results[j])));
                    
                }
            }
        }

        function createMarker(place) {
            var placeLoc = place.geometry.location;
            var marker = new google.maps.Marker({
                map: map,
                position: place.geometry.location
            });

            google.maps.event.addListener(marker, 'click', function(){
               infowindow.setContent(place.name);
               infowindow.open(map, this);
            });
            
            return marker;
        }

        function clearResults(markers){
            for(var m in markers){
                markers[m].setMap(null)
            }
            markers = []
        }

        google.maps.event.addDomListener(window, 'load', initialize);
        </script>

        <style>
        html, body, #map {
            height: 100%;
            width: 100%;
            margin: 0px;
            padding: 0px;
        }
        </style>
    </head>
    <body>
        <div id="map"></div>
    </body>

</html>