<?php


    include 'newMapSearch.php';

    $servername = "localhost";
    $username = "root";
    $password = "mysql";
    $databaseName = "OvercrowdDB";
    $ipaddress = $_SERVER['REMOTE_ADDR'];
    $connection = new mysqli($servername, $username, $password, $databaseName);
    if($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }
    $insertSQL = "INSERT INTO GoogleMapsInfo (name) VALUES('$temp')";
    if ($connection->query($insertSQL) === TRUE) {
        echo "Success: We will submit the following information<br>";
        echo $name . "<br>";
        echo $email . "<br>";
        echo $comment . "<br>";
        echo $ipaddress . "<br>";
        }
        else {
            echo "Error: " . $insertSQL . "<br>" . $connection->error;
        }
        ?>